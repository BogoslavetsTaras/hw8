import React from "react";

export function Header() {
  return (
    <div className="container is-fluid title is-1 has-text-centered">
      Market admin panel. You can add items, see all items, edit and delete them
    </div>
  );
}
